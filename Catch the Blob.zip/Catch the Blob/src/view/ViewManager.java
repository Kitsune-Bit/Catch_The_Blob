package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import java.util.List;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import java.util.ArrayList;
import entities.MainMenuButtons;

public class ViewManager {

    private static final int width = 1280;
    private static final int height = 720;

    private AnchorPane mainPane;
    private Scene mainScene;
    private Stage mainStage;

    public ViewManager() {
        mainPane = new AnchorPane();
        mainScene = new Scene(mainPane, width, height);
        mainStage = new Stage();
        mainStage.setScene(mainScene);
        createBackground();
        createLogo();
        createButtons();

    }

    public Stage getMainStage(){
        return mainStage;
    }

    private void createBackground() {
        BackgroundImage background = new BackgroundImage(new Image("/pictures/background.jpg", 1280,
                720, false, false), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                BackgroundSize.DEFAULT);

        mainPane.setBackground(new Background(background));
    }

    private void createLogo(){
        ImageView logo = new ImageView("/pictures/logo_640x160.png");

        logo.setLayoutX(340);
        logo.setLayoutY(25);

        mainPane.getChildren().add(logo);

    }

    private void createButtons() {
        MainMenuButtons button = new MainMenuButtons("TEST!");
        mainPane.getChildren().add(button);

        button.setLayoutX(100);
        button.setLayoutY(225);

    }



}